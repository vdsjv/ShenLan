Page({
    data: {
        deviceName: "HC-08",
        isConnected: !1,
        isFailed: !0,
        isFinded: !1,
        deviceId: "5328BAD8-7CB0-6018-0E24-2F6611937940",
        serviceId: "0000FFE0-0000-1000-8000-00805F9B34FB",
        characteristicId: "0000FFE1-0000-1000-8000-00805F9B34FB"
    },
    onSendq: function() {
        var t = this, e = new ArrayBuffer(5), i = new DataView(e);
        i.setUint8(0, 1), i.setUint8(1, 2), i.setUint8(2, 3), i.setUint8(3, 4), i.setUint8(4, 1), 
        console.log("发送的数据：");
        for (var a = 0; a < i.byteLength; a++) console.log("0x" + i.getUint8(a).toString(16));
        t.data.serviceId && t.data.characteristicId ? wx.writeBLECharacteristicValue({
            deviceId: t.data.deviceId,
            serviceId: t.data.serviceId,
            characteristicId: t.data.characteristicId,
            value: e,
            success: function(t) {
                console.log("发送指令成功"), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(t) {
                console.warn("发送指令失败", t);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    },
    onSendw: function() {
        var t = this, e = new ArrayBuffer(5), i = new DataView(e);
        i.setUint8(0, 1), i.setUint8(1, 2), i.setUint8(2, 3), i.setUint8(3, 4), i.setUint8(4, 2), 
        console.log("发送的数据：");
        for (var a = 0; a < i.byteLength; a++) console.log("0x" + i.getUint8(a).toString(16));
        t.data.serviceId && t.data.characteristicId ? wx.writeBLECharacteristicValue({
            deviceId: t.data.deviceId,
            serviceId: t.data.serviceId,
            characteristicId: t.data.characteristicId,
            value: e,
            success: function(t) {
                console.log("发送指令成功"), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(t) {
                console.warn("发送指令失败", t);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    },
    onSende: function() {
        var t = this, e = new ArrayBuffer(5), i = new DataView(e);
        i.setUint8(0, 1), i.setUint8(1, 2), i.setUint8(2, 3), i.setUint8(3, 4), i.setUint8(4, 3), 
        console.log("发送的数据：");
        for (var a = 0; a < i.byteLength; a++) console.log("0x" + i.getUint8(a).toString(16));
        t.data.serviceId && t.data.characteristicId ? wx.writeBLECharacteristicValue({
            deviceId: t.data.deviceId,
            serviceId: t.data.serviceId,
            characteristicId: t.data.characteristicId,
            value: e,
            success: function(t) {
                console.log("发送指令成功"), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(t) {
                console.warn("发送指令失败", t);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    },
    onSendr: function() {
        var t = this, e = new ArrayBuffer(5), i = new DataView(e);
        i.setUint8(0, 1), i.setUint8(1, 2), i.setUint8(2, 3), i.setUint8(3, 4), i.setUint8(4, 4), 
        console.log("发送的数据：");
        for (var a = 0; a < i.byteLength; a++) console.log("0x" + i.getUint8(a).toString(16));
        t.data.serviceId && t.data.characteristicId ? wx.writeBLECharacteristicValue({
            deviceId: t.data.deviceId,
            serviceId: t.data.serviceId,
            characteristicId: t.data.characteristicId,
            value: e,
            success: function(t) {
                console.log("发送指令成功"), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(t) {
                console.warn("发送指令失败", t);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    },
    onSendt: function() {
        var t = this, e = new ArrayBuffer(5), i = new DataView(e);
        i.setUint8(0, 1), i.setUint8(1, 2), i.setUint8(2, 3), i.setUint8(3, 4), i.setUint8(4, 5), 
        console.log("发送的数据：");
        for (var a = 0; a < i.byteLength; a++) console.log("0x" + i.getUint8(a).toString(16));
        t.data.serviceId && t.data.characteristicId ? wx.writeBLECharacteristicValue({
            deviceId: t.data.deviceId,
            serviceId: t.data.serviceId,
            characteristicId: t.data.characteristicId,
            value: e,
            success: function(t) {
                console.log("发送指令成功"), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(t) {
                console.warn("发送指令失败", t);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    }
});