getApp();

Page({
    data: {
        deviceName: "MLT-BT05",
        isConnected: !1,
        isFailed: !0,
        isFinded: !1
    },
    onLoad: function() {},
    onClock: function(e) {
        wx.navigateTo({
            url: "/pages/clocks/clock"
        });
    },
    onHeartRate: function(e) {
        wx.navigateTo({
            url: "/pages/heart/heart"
        });
    },
    onFoot: function(e) {
        wx.navigateTo({
            url: "/pages/foot/foot?id=3"
        });
    },
    onSendCommandq: function(e) {
        wx.navigateTo({
            url: "/pages/records/record?id=3"
        });
    },
    onConnect: function() {
        var e = this;
        wx.openBluetoothAdapter({
            success: function(t) {
                e.data.isConnected || (e.startBluetoothDevicesDiscovery(), wx.showLoading({
                    title: "搜索中"
                }));
            },
            fail: function(e) {
                wx.showToast({
                    title: "请先开启蓝牙",
                    icon: "none",
                    duration: 1e3
                });
            }
        });
    },
    startBluetoothDevicesDiscovery: function() {
        var e = this;
        wx.startBluetoothDevicesDiscovery({
            success: function(t) {
                console.log("discovery", t), 0 == t.errCode && e.getConnect();
            }
        });
    },
    getConnect: function() {
        var e = this, t = setInterval(function() {
            wx.getBluetoothDevices({
                success: function(o) {
                    console.log("devices", o);
                    for (var n = 0; n < o.devices.length; n++) if (o.devices[n].name == e.data.deviceName) {
                        wx.hideLoading(), wx.showLoading({
                            title: "连接中"
                        }), e.setData({
                            isFinded: !0
                        }), clearInterval(t), e.setData({
                            deviceId: o.devices[n].deviceId
                        }), console.log("设备号", e.data.deviceId), console.log("开始尝试建立连接"), wx.createBLEConnection({
                            deviceId: e.data.deviceId,
                            timeout: 1e4,
                            success: function(t) {
                                console.log(t), 0 == t.errCode ? (console.log("连接成功"), e.setData({
                                    isConnected: !0
                                }), wx.stopBluetoothDevicesDiscovery()) : wx.showModal({
                                    title: "提示",
                                    content: "不能正常对蓝牙设备进行连接",
                                    showCancel: !1
                                });
                            },
                            fail: function(e) {
                                wx.hideLoading(), 10012 == e.errCode && wx.showModal({
                                    title: "提示",
                                    content: "连接超时",
                                    showCancel: !1
                                }), console.warn("fail", e);
                            },
                            complete: function() {
                                wx.hideLoading();
                            }
                        });
                        break;
                    }
                }
            });
        }, 3e3);
        setTimeout(function() {
            e.data.isFinded || e.data.isConnected || (clearInterval(t), e.setData({
                isFailed: !1
            }), wx.hideLoading(), wx.showModal({
                title: "提示",
                content: "搜索蓝牙超时",
                showCancel: !1
            }));
        }, 12e3);
    },
    ab2hex: function(e) {
        return Array.prototype.map.call(new Uint8Array(e), function(e) {
            return ("00" + e.toString(16)).slice(-2);
        }).join("");
    },
    onSendCommandm: function() {
        var e = this, t = new ArrayBuffer(10), o = new DataView(t), n = Date.parse(new Date());
        n /= 1e3, console.log("当前时间戳为：" + n);
        var i = new Array(4), c = n + 28800;
        i[0] = parseInt(c / 256 / 256 / 256), i[1] = parseInt(c / 256 / 256) - 256 * parseInt(c / 256 / 256 / 256), 
        i[2] = parseInt(c / 256) - 256 * parseInt(c / 256 / 256), i[3] = c % 256, console.log(i);
        var a = new Array(6);
        a[3] = i[0].toString(16), a[2] = i[1].toString(16), a[1] = i[2].toString(16), a[0] = i[3].toString(16), 
        a[4] = 140 + i[0] + i[1] + i[2] + i[3], a[5] = a[4].toString(16), console.log(a), 
        o.setUint8(0, 104), o.setUint8(1, 32), o.setUint8(2, 4), o.setUint8(3, 0), o.setUint8(4, "0x" + a[0]), 
        o.setUint8(5, "0x" + a[1]), o.setUint8(6, "0x" + a[2]), o.setUint8(7, "0x" + a[3]), 
        o.setUint8(8, "0x" + a[5]), o.setUint8(9, 22), console.log("发送的数据：");
        for (var s = 0; s < o.byteLength; s++) console.log("0x" + o.getUint8(s).toString(16));
        e.data.serviceId && e.data.characteristicWriteId ? wx.writeBLECharacteristicValue({
            deviceId: e.data.deviceId,
            serviceId: e.data.serviceId,
            characteristicId: e.data.characteristicWriteId,
            value: t,
            success: function(t) {
                console.log("发送指令成功"), console.log(e.data.deviceId), console.log(e.data.serviceId), 
                console.log(e.data.characteristicWriteId), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(e) {
                console.warn("发送指令失败", e);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    },
    onSendCommands: function() {
        var e = this, t = new ArrayBuffer(5), o = new DataView(t);
        o.setUint8(0, 1), o.setUint8(1, 2), o.setUint8(2, 3), o.setUint8(3, 4), o.setUint8(4, 1), 
        console.log("发送的数据：");
        for (var n = 0; n < o.byteLength; n++) console.log("0x" + o.getUint8(n).toString(16));
        e.data.serviceId && e.data.characteristicWriteId ? wx.writeBLECharacteristicValue({
            deviceId: e.data.deviceId,
            serviceId: e.data.serviceId,
            characteristicId: e.data.characteristicWriteId,
            value: t,
            success: function(e) {
                console.log("发送指令成功"), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(e) {
                console.warn("发送指令失败", e);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    },
    onSendCommandf: function() {
        var e = this, t = new ArrayBuffer(5), o = new DataView(t), n = new Date().getTime();
        console.log("当前时间戳为：" + n);
        var i = new Array(3), c = n + 288e5, a = parseInt(c % 864e5 / 36e5), s = parseInt(c % 36e5 / 6e4), r = c % 6e4 / 1e3;
        i[0] = a.toString(16), i[1] = s.toString(16), i[2] = r.toString(16), console.log("当前小时为：" + a + "16进制时间为：" + i[0]), 
        console.log("当前分钟为：" + s + "16进制时间为：" + i[1]), console.log("当前秒为：" + r + "16进制时间为：" + i[2]), 
        o.setUint8(0, "0x" + i[0]), o.setUint8(1, "0x" + i[1]), o.setUint8(2, "0x" + i[2]), 
        o.setUint8(3, 65), o.setUint8(4, 61), console.log("发送的数据：");
        for (var d = 0; d < o.byteLength; d++) console.log("0x" + o.getUint8(d).toString(16));
        e.data.serviceId && e.data.characteristicWriteId ? wx.writeBLECharacteristicValue({
            deviceId: e.data.deviceId,
            serviceId: e.data.serviceId,
            characteristicId: e.data.characteristicWriteId,
            value: t,
            success: function(e) {
                console.log("发送指令成功"), wx.showToast({
                    title: "发送成功",
                    icon: "none"
                });
            },
            fail: function(e) {
                console.warn("发送指令失败", e);
            }
        }) : wx.showModal({
            title: "提示",
            content: "请先获取设备信息",
            showCancel: !1
        });
    },
    onGetuuid: function() {
        var e = this;
        e.data.isConnected ? (wx.showLoading({
            title: "获取serviceId"
        }), console.log("开始获取设备信息"), wx.getBLEDeviceServices({
            deviceId: e.data.deviceId,
            success: function(t) {
                console.log("getServicesRes", t);
                var o = t.services[1].uuid;
                wx.showLoading({
                    title: "获取characteristicNotifyId"
                }), wx.getBLEDeviceCharacteristics({
                    deviceId: e.data.deviceId,
                    serviceId: o,
                    success: function(t) {
                        console.log("getCharactersRes", t), wx.hideLoading();
                        var n = t.characteristics[0], i = t.characteristics[0], c = n.uuid, a = i.uuid;
                        e.setData({
                            serviceId: o,
                            characteristicNotifyId: a,
                            characteristicWriteId: c
                        }), console.log("成功获取uuId", e.data.serviceId, e.data.characteristicNotifyId), wx.notifyBLECharacteristicValueChange({
                            state: !0,
                            deviceId: e.data.deviceId,
                            serviceId: o,
                            characteristicId: a,
                            success: function() {
                                console.log("开始监听特征值"), wx.onBLECharacteristicValueChange(function(t) {
                                    console.log("监听到特征值更新", t);
                                    var o = e.ab2hex(t.value);
                                    console.log("拿到的数据", o);
                                });
                            },
                            fail: function(e) {
                                console.warn("监听特征值失败");
                            }
                        });
                    },
                    fail: function(e) {
                        console.warn("获取特征值信息失败", e);
                    },
                    complete: function(e) {
                        console.log("获取服务信息完成", e), wx.hideLoading();
                    }
                });
            },
            fail: function(e) {
                console.warn("获取服务信息失败", e);
            },
            complete: function() {
                wx.hideLoading();
            }
        })) : wx.showToast({
            title: "请先连接蓝牙"
        });
    },
    onCloseConnect: function() {
        this.setData({
            isConnected: !1,
            isFinded: !1
        }), wx.closeBLEConnection({
            deviceId: this.data.deviceId,
            success: function(e) {
                console.log("成功断开连接"), wx.showToast({
                    title: "成功断开连接"
                });
            }
        });
    }
});