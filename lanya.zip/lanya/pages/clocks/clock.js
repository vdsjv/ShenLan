Page({
    data: {
        hourq: "00",
        minuteq: "00",
        hourw: "00",
        minutew: "00",
        houre: "00",
        minutee: "00"
    },
    onSetTimeq: function() {
        wx.navigateTo({
            url: "/pages/clocks/clock-item/clock-itemq"
        });
    },
    onSetTimew: function() {
        wx.navigateTo({
            url: "/pages/clocks/clock-item/clock-itemw"
        });
    },
    onSetTimee: function() {
        wx.navigateTo({
            url: "/pages/clocks/clock-item/clock-iteme"
        });
    },
    onSetContentq: function() {
        wx.navigateTo({
            url: "/pages/clocks/clock-content/clock-contentq"
        });
    },
    onSetContentw: function() {
        wx.navigateTo({
            url: "/pages/clocks/clock-content/clock-contentw"
        });
    },
    onSetContente: function() {
        wx.navigateTo({
            url: "/pages/clocks/clock-content/clock-contente"
        });
    },
    onLoad: function(e) {
        var t = this, n = wx.getStorageSync("timeDataq", n), o = wx.getStorageSync("timeDataw", o), c = wx.getStorageSync("timeDatae", c);
        t.setData({
            hourq: n.hour,
            minuteq: n.minute,
            hourw: o.hour,
            minutew: o.minute,
            houre: c.hour,
            minutee: c.minute
        });
    },
    onshouye: function() {
        wx.reLaunch({
            url: "/pages/index/index"
        });
    }
});