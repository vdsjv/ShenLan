Page({
    data: {},
    onLoad: function(n) {
        var t = this, o = wx.getStorageSync("contentq", o);
        t.setData({
            details: o.content
        });
    },
    onSetContent: function(n) {
        var t = this;
        t.setData({
            details: n.detail.value
        }), console.log(t.data.details), console.log(n.detail.value);
        var o = {
            content: t.data.details
        };
        wx.setStorageSync("contentq", o), wx.reLaunch({
            url: "/pages/clocks/clock?id=1"
        });
    },
    onReady: function() {},
    onShow: function() {},
    onHide: function() {},
    onUnload: function() {},
    onPullDownRefresh: function() {},
    onReachBottom: function() {},
    onShareAppMessage: function() {}
});