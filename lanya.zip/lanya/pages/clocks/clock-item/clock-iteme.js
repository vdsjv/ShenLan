for (var e = new Date(), t = [], a = [], i = 0; i <= 23; i++) t.push(i);

for (var o = 0; o <= 59; o++) a.push(o);

Page({
    data: {
        deviceName: "MLT-BT05",
        isConnected: !1,
        isFailed: !0,
        isFinded: !1,
        hours: t,
        hour: e.getHours(),
        minutes: a,
        minute: e.getMinutes(),
        value: [ 0, 0 ],
        deviceId: "5328BAD8-7CB0-6018-0E24-2F6611937940",
        serviceId: "0000FFE0-0000-1000-8000-00805F9B34FB",
        characteristicId: "0000FFE1-0000-1000-8000-00805F9B34FB"
    },
    bindChange: function(e) {
        var t = e.detail.value;
        this.setData({
            hour: this.data.hours[t[0]],
            minute: this.data.minutes[t[1]]
        }), console.log(t[0], t[1]);
        var a = t[0], i = t[1];
        console.log(a, i), console.log(a);
    },
    onSendTime: function() {
        var e = this, t = new ArrayBuffer(5), a = new DataView(t);
        console.log(e.data.hour), console.log(e.data.minute);
        var i = new Array(2);
        i[0] = e.data.hour.toString(16), i[1] = e.data.minute.toString(16), a.setUint8(0, "0x" + i[0]), 
        a.setUint8(1, "0x" + i[1]), a.setUint8(2, 0), a.setUint8(3, 68), a.setUint8(4, 64), 
        console.log("发送的数据：");
        for (var o = 0; o < a.byteLength; o++) console.log("0x" + a.getUint8(o).toString(16));
        wx.writeBLECharacteristicValue({
            deviceId: e.data.deviceId,
            serviceId: e.data.serviceId,
            characteristicId: e.data.characteristicId,
            value: t,
            success: function(e) {
                console.log("发送指令成功"), wx.showToast({
                    title: "设置闹钟成功",
                    icon: "none"
                });
            },
            fail: function(e) {
                console.warn("设置闹钟失败", e);
            }
        }), setTimeout(function() {}, 1e3), wx.reLaunch({
            url: "/pages/clocks/clock?id=1"
        });
        var n = {
            hour: e.data.hour,
            minute: e.data.minute
        };
        wx.setStorageSync("timeDatae", n);
    }
});