for (var t = new Date(), e = [], a = [], o = 0; o <= 23; o++) e.push(o);

for (var i = 0; i <= 59; i++) a.push(i);

Page({
    data: {
        deviceName: "MLT-BT05",
        isConnected: !1,
        isFailed: !0,
        isFinded: !1,
        hours: e,
        hour: t.getHours(),
        minutes: a,
        minute: t.getMinutes(),
        value: [ 0, 0 ],
        deviceId: "5328BAD8-7CB0-6018-0E24-2F6611937940",
        serviceId: "0000FFE0-0000-1000-8000-00805F9B34FB",
        characteristicId: "0000FFE1-0000-1000-8000-00805F9B34FB"
    },
    bindChange: function(t) {
        var e = t.detail.value;
        this.setData({
            hour: this.data.hours[e[0]],
            minute: this.data.minutes[e[1]]
        }), console.log(e[0], e[1]);
        var a = e[0], o = e[1];
        console.log(a, o), console.log(a);
    },
    onSendTime: function() {
        var t = this, e = new ArrayBuffer(5), a = new DataView(e);
        console.log(t.data.hour), console.log(t.data.minute);
        var o = new Array(2);
        o[0] = t.data.hour.toString(16), o[1] = t.data.minute.toString(16), console.log(t.data.hour.toString(16)), 
        console.log(t.data.minute.toString(16)), a.setUint8(0, "0x" + o[0]), a.setUint8(1, "0x" + o[1]), 
        a.setUint8(2, 0), a.setUint8(3, 66), a.setUint8(4, 62), console.log("发送的数据：");
        for (var i = 0; i < a.byteLength; i++) console.log("0x" + a.getUint8(i).toString(16));
        wx.writeBLECharacteristicValue({
            deviceId: t.data.deviceId,
            serviceId: t.data.serviceId,
            characteristicId: t.data.characteristicId,
            value: e,
            success: function(t) {
                console.log("发送指令成功"), wx.showToast({
                    title: "设置闹钟成功",
                    icon: "none"
                });
            },
            fail: function(t) {
                console.warn("设置闹钟失败", t);
            }
        }), setTimeout(function() {}, 1e3), wx.reLaunch({
            url: "/pages/clocks/clock?id=1"
        });
        var n = {
            hour: t.data.hour,
            minute: t.data.minute
        };
        wx.setStorageSync("timeDataq", n);
    }
});